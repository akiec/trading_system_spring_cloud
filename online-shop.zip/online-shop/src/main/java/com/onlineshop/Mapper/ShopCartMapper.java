package com.onlineshop.Mapper;

public interface ShopCartMapper {
}
