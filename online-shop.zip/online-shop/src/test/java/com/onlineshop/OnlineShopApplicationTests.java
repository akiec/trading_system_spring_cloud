package com.onlineshop;

import com.onlineshop.Utils.IdCreater;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
