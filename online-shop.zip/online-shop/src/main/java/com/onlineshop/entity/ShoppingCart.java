package com.onlineshop.entity;

public class ShoppingCart {

}
