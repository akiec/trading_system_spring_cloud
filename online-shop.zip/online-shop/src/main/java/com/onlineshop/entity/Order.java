package com.onlineshop.entity;

public class Order {
    private Long orderId;
    private Long customerId;
    private Long productId;
    private Long paymentId;

}
