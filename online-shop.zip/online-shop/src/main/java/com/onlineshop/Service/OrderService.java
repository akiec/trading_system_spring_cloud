package com.onlineshop.Service;

public interface OrderService {
}
