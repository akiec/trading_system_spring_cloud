package com.onlineshop.Mapper;

public interface OrderMapper {
}
