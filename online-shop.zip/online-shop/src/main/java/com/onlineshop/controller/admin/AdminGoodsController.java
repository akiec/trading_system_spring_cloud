package com.onlineshop.controller.admin;

public class AdminGoodsController {
}
