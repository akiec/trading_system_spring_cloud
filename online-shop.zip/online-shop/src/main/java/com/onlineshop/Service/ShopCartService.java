package com.onlineshop.Service;

public interface ShopCartService {
}
